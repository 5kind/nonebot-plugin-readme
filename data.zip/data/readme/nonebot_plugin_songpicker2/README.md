# songpicker2
适用于nonebot2的点歌插件，数据源为网易云音乐

> 能开源出来的新版本还在摸，暂时先当api参考项目用吧。

## 安装
* 使用nb-cli（推荐）  
```shell
nb plugin install nonebot_plugin_songpicker2
```

* 使用poetry
```shell
poetry add nonebot_plugin_songpicker2
```

* 使用git clone（不推荐）
```shell
git clone https://github.com/maxesisn/TachibanaBot2
  
之后手动复制文件或创建软链接
```

## 开始使用
发送`点歌+歌曲名`，从插件所给的候选项中选择歌曲。

## 配置
_还没做_
