# nonebot-plugin-emojimix

适用于 [Nonebot2](https://github.com/nonebot/nonebot2) 的 emoji 合成器

😎+😁=？


### 安装

- 使用 nb-cli

```
nb plugin install nonebot_plugin_emojimix
```

- 使用 pip

```
pip install nonebot_plugin_emojimix
```

若经常下载出错，可以在 `.env.xxx` 文件中设置代理：

```
http_proxy=http://ip:port
```


### 示例

<div align="left">
  <img src="https://s2.loli.net/2022/01/23/EyoA1BHe9YpJZUD.png" width="400" />
</div>
