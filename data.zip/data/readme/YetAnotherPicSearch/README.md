# YetAnotherPicSearch

基于 [nonebot/nonebot2](https://github.com/nonebot/nonebot2) 及 [kitUIN/PicImageSearch](https://github.com/kitUIN/PicImageSearch) 的另一个 Nonebot 搜图插件。

目前适配的是 `OneBot V11` ，没适配 QQ 频道。

主要受到 [Tsuk1ko/cq-picsearcher-bot](https://github.com/Tsuk1ko/cq-picsearcher-bot) 的启发，以及其遇到的问题 [Tsuk1ko/cq-picsearcher-bot#283](https://github.com/Tsuk1ko/cq-picsearcher-bot/issues/283) 不好解决。

此外，我只需要基础的搜图功能，加上一些小调整，于是忍不住自己也写了一个。
