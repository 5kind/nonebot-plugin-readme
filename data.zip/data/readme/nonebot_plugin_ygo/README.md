<!--
 * @Author         : anlen123
 * @Date           : 2022-03-02 00:00:00
 * @LastEditors    : anlen123
 * @LastEditTime   : 2022-02-02 00:00:00
 * @Description    : None
 * @GitHub         : https://github.com/anlen123/nonebot_plugin_ygo
-->

<p align="center">
  <a href="https://v2.nonebot.dev/"><img src="https://v2.nonebot.dev/logo.png" width="200" height="200" alt="nonebot"></a>
</p>

<div align="center">

# nonebot_plugin_ygo


_✨ NoneBot nonebot的游戏王卡查插件 ✨_

</div>

<p align="center">
  <a href="https://raw.githubusercontent.com/cscs181/QQ-Github-Bot/master/LICENSE">
    <img src="https://img.shields.io/github/license/cscs181/QQ-Github-Bot.svg" alt="license">
  </a>
  <a href="https://pypi.python.org/pypi/nonebot-plugin-ygo">
    <img src="https://img.shields.io/pypi/v/nonebot-plugin-ygo.svg" alt="pypi">
  </a>
  <img src="https://img.shields.io/badge/python-3.7+-blue.svg" alt="python">
</p>

## 使用方式
ygo key

例如：
ygo 闪刀

群聊

<img width="615" alt="image" src="https://user-images.githubusercontent.com/49887895/156330040-29e48697-b48f-4aac-aabb-d8714639f84f.png">



<img width="600" alt="image" src="https://user-images.githubusercontent.com/49887895/156330065-272a2df2-d8e4-4b6d-9cde-12e87c29d3e7.png">

私聊

<img width="1553" alt="image" src="https://user-images.githubusercontent.com/49887895/156330126-3e98562e-db0a-4e6d-a492-020e3e791d70.png">


ygo 龙女仆

ygo 海晶少女

ygo 拿妈


## 配置

表示最大查询卡数

YGO_MAX=10


## 安装
pip install nonebot-plugin-ygo

## 使用
nonebot.load_plugin('nonebot_plugin_ygo')


# 已适配nonebot beta版本
