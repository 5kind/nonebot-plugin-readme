# 关于 readme 插件
暂未完成
推荐manager插件
使用 readme [插件名称] 的方式阅读插件列表

## 代办
使用download.py更新文档     readme update
使用readme.py更新readme    readme upgrade