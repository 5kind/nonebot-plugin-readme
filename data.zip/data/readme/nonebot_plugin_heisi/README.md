<p align="center">
  <a href="https://v2.nonebot.dev/"><img src="https://raw.githubusercontent.com/nonebot/nonebot2/master/docs/.vuepress/public/logo.png" width="200" height="200" alt="nonebot"></a>
</p>

<div align="center">

# Hei Si

_✨ NoneBot2 黑丝 ✨_

</div>


用于发送色色图片，内置CD

请在 `.env.dev`中做出如下配置：
```

heisi_group=["237161342"] #黑丝白名单
heisi_cd=30 #黑丝cd时间（s）

```

## 安装💿
`pip install nonebot-plugin-heisi`


## 导入📲
在**bot.py** 导入，语句：
`nonebot.load_plugin("nonebot_plugin_heisi")`



## 指令💻
```
.黑丝
.丝袜
```


**给个star吧~**

其他插件
[在线运行代码](https://github.com/yzyyz1387/nonebot_plugin_code)
[it咨询](https://github.com/yzyyz1387/nonebot_plugin_itnews "it资讯")
[工作性价比](https://github.com/yzyyz1387/nonebot_plugin_workscore)

## 截图🖼

没有


