# 这个插件还没有readme
[给作者提交issue](https://github.com/echobot-dev/nonebot-plugin-strman)