# nonebot_plugin_forwarder
A plugin based on NoneBot2, which can broadcast message from Source Groups to Destinated Groups.
