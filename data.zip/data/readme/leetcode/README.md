# leetcode每日一题提醒插件

## 安装该插件后能往指定qq和指定qq群定时发送leetcode每日一题

## 配置方法如下
以下配置均大小写不敏感\
在nonebot的env配置文件中输入以下配置内容
```angular2html

LEETCODE_QQ_FRIENDS=[948125001,123456]
LEETCODE_QQ_GROUPS=[238112475]

LEETCODE_INFORM_TIME=[{"HOUR":19,"MINUTE":33},{"HOUR":19,"MINUTE":34},{"HOUR":19,"MINUTE":35}]
```
LEETCODE_QQ_FRIENDS:指定的qq\
LEETCODE_QQ_GROUPS:指定的qq群\
LEETCODE_INFORM_TIME:设置定时触发的时间
