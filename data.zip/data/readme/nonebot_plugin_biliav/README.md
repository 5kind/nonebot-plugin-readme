<!--
 * @Author         : anlen123
 * @Date           : 2021-03-01 00:00:00
 * @LastEditors    : anlen123
 * @LastEditTime   : 2021-03-01 00:00:00
 * @Description    : None
 * @GitHub         : https://github.com/anlen123/nonebot_plugin_abbrreply
-->

<p align="center">
  <a href="https://v2.nonebot.dev/"><img src="https://raw.githubusercontent.com/nonebot/nonebot2/master/docs/.vuepress/public/logo.png" width="200" height="200" alt="nonebot"></a>
</p>

<div align="center">

# nonebot_plugin_biliav


_✨ NoneBot biliav小程序 查看插件 ✨_

</div>

<p align="center">
  <a href="https://raw.githubusercontent.com/cscs181/QQ-Github-Bot/master/LICENSE">
    <img src="https://img.shields.io/github/license/cscs181/QQ-Github-Bot.svg" alt="license">
  </a>
  <a href="https://pypi.python.org/pypi/nonebot-plugin-status">
    <img src="https://img.shields.io/pypi/v/nonebot-plugin-status.svg" alt="pypi">
  </a>
  <img src="https://img.shields.io/badge/python-3.7+-blue.svg" alt="python">
</p>

## 使用方式
发送：
av170001

或者BV17x411w7KC

返回b站小程序对应的视频

## 安装
pip install nonebot_plugin_biliav
