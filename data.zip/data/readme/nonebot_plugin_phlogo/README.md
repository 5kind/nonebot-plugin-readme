# nonebot-plugin-phlogo

生成ph风格logo

![nb](docs/png.png)
# 安装

直接使用 `pip install nonebot-plugin-phlogo` 进行安装

然后在 `bot.py` 中 写入 `nonebot.load_plugin("nonebot_plugin_phlogo")`

# 指令

`phlogo/pornhub/ph图标 [text1] [text2]`

# 配置

## 字体文件 可选 环境配置

```
PHLOGO_FONT = "./data/font.ttf"
```

- 使用 truetype 字体
- 建议使用微软雅黑
