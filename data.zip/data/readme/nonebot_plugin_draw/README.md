# nonebot_plugin_draw
## 介绍
一个本地化的抽签小插件，最好在python3.9版本以上使用
## 使用方法
输入“关帝灵签”来触发，按照提示进行抽签
## 使用pip安装
命令：
```
pip install nonebot_plugin_draw
```
在bot入口文件添加：
```
nonebot.load_plugin("pin install nonebot_plugin_draw")
```
## 使用效果
![9FE3FE9154B4F2F53FDF456CF1206F4A](https://user-images.githubusercontent.com/98812723/161758808-32a399bb-d969-4022-9ad9-ff65745f557d.jpg)
![Uploading 7ECE8EF9034F8E902B6B41589929D1AC.jpg…]()
